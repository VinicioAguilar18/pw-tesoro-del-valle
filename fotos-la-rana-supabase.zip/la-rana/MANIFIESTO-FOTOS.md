# 📸 Fotos Alojamiento La Rana — listas para Supabase

**Cómo subirlas:** Supabase → Storage → bucket `photos` → crea la carpeta `la-rana/gallery/` → arrastra los 14 archivos .webp.
Ruta final de cada foto: `photos/la-rana/gallery/{nombre}.webp`

| Archivo | Uso sugerido | Alt ES / EN |
|---|---|---|
| hero-vista-dron.webp | **HERO de la landing** (vista aérea, formato panorámico) | Vista aérea de La Rana entre el bosque / Aerial view of La Rana in the rainforest |
| jacuzzi-01..04.webp | Galería parallax + tarjeta "Jacuzzi" del Concierge | Jacuzzi privado al aire libre / Private outdoor jacuzzi |
| casa-01, casa-02.webp | Galería parallax (exterior) | Exterior del alojamiento / Property exterior |
| habitacion-01.webp | Galería + sección "El espacio" | Habitación acogedora / Cozy bedroom |
| bano-01.webp | Sección "El espacio" | Baño privado / Private bathroom |
| cocina-01.webp | Galería + tarjeta "Cocina" del Concierge | Cocina equipada / Fully equipped kitchen |
| comedor-01.webp | Sección "El espacio" | Comedor / Dining area |
| sala-01.webp | Sección "El espacio" | Sala de estar / Living room |
| patio-01.webp | Galería parallax | Terraza con mobiliario exterior / Terrace with outdoor furniture |
| jardin-piedra-01.webp | Galería (única VERTICAL — ideal para composición parallax mixta) | Jardín y naturaleza / Garden and nature |

Notas técnicas: WebP calidad 82, listas para `next/image`. Total: ~2.1 MB las 14.
